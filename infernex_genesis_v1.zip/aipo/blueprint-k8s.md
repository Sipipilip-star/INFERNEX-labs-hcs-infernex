# AIPO Kubernetes blueprint (summary)
- llm-gateway (Deployment, Service)
- embedder (Deployment)
- agent-operator (Deployment)
- agent-runner (Job template)
- mesh (linkerd/istio recommended)
- external-secrets + vault
- opa + gatekeeper
- observability (prometheus, otel)
