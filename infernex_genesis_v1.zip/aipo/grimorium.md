# AIPO Grimorium — The Book of Flow

AIPO is the AI Payment Orchestrator — the living logic that routes value across rails, protects the brand,
and optimizes fees and liquidity. The Grimorium documents abilities, rituals, and interfaces.

Core capabilities:
- Omni-route Vision
- Fee Optimization Engine (FOE)
- Predictive Rail Forecaster (PRF)
- Reputation-Aware Routing (RAR)
- Self-Healing Layer (SHL)
