# Intelligent Due Diligence Checklist (summary)

- Architecture diagrams and runbooks
- Security posture: OPA/Gatekeeper, Vault, ExternalSecrets, HSM for keys
- Smart-contract audits and testnet run
- Compliance: KYC/AML flow for FIAT rails and prediction markets
- Model safety & RLHF provenance (replay store + Merkle snapshots)
- Legal: token sale regulatory review by counsel
