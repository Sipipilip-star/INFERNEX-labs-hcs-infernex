# BROUK Tokenomics (v1 genesis)

Total supply: 1,000,000,000 BROUK
Allocation:
- 35% Ecosystem Growth (350,000,000)
- 25% Treasury / DAO (250,000,000)
- 12% Team (120,000,000) - 4y vesting, 1y cliff
- 15% Investors (150,000,000)
- 10% Staking / Validators (100,000,000)
- 3% Partners / Advisors (30,000,000)

Mechanics:
- Fee split: 60% treasury, 20% buyback+burn, 10% stakers, 10% ops
- Stabilizer: Treasury holds fiat/stable reserves and triggers ABR when token < threshold
- Activity Score: drives reward multipliers and governance weight
- Adaptive Buyback Reactor (ABR): auto buyback/burn logic
