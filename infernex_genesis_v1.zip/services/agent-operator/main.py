import kopf, kubernetes, os, yaml, logging
from kubernetes.client import BatchV1Api
logging.basicConfig(level=logging.INFO)
@kopf.on.startup()
def startup(settings: kopf.OperatorSettings, **_):
    settings.posting.level = logging.INFO
@kopf.on.create('infernex.io', 'v1', 'agenttasks')
def on_agenttask_create(spec, name, namespace, logger, **kwargs):
    logger.info(f'AgentTask {name} created in {namespace} with spec: {spec}')
    batch = BatchV1Api()
    job = {
      'apiVersion': 'batch/v1',
      'kind': 'Job',
      'metadata': {'name': f'agenttask-{name}', 'namespace': namespace},
      'spec': {'template': {'metadata': {'name': f'agenttask-{name}'}, 'spec': {'restartPolicy': 'Never', 'containers': [{'name': 'agent-runner', 'image': spec.get('image','ghcr.io/REPLACE_ORG/infernex-agent-runner:REPLACE_SHA'), 'env': [{'name':'TASK_SPEC','value': yaml.safe_dump(spec)}], 'args': ['--task-id', name]}]}}}
    batch.create_namespaced_job(namespace=namespace, body=job)
    return {'job': f'agenttask-{name}'}
