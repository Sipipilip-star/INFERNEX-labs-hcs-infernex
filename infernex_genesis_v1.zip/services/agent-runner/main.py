import os, requests, time, logging
logging.basicConfig(level=logging.INFO)
task_spec = os.getenv('TASK_SPEC', '{}')
AIPO_ENDPOINT = os.getenv('AIPO_ENDPOINT','http://aipo.infernex-core.svc:8080/negotiation')
payload = {'task': task_spec, 'proposal': {'fee_pct': 0.12, 'notes':'auto-negotiated stub'}}
try:
    r = requests.post(AIPO_ENDPOINT, json=payload, timeout=10)
    logging.info('AIPO response %s %s', r.status_code, r.text[:200])
except Exception as e:
    logging.warning('AIPO post failed: %s', e)
time.sleep(1)
logging.info('Agent completed')
