from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os, httpx, logging
app = FastAPI(title='INFERNEX LLM Gateway (real-capable)')
logging.basicConfig(level=logging.INFO)
MODEL_BACKENDS = os.getenv('MODEL_BACKENDS','openai').split(',')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY','')
ANTHROPIC_API_KEY = os.getenv('ANTHROPIC_API_KEY','')
TIMEOUT = int(os.getenv('LLM_TIMEOUT','20'))
class LLMReq(BaseModel):
    prompt: str
    model_hint: str = 'gpt-4o-mini'
    stream: bool = False
async def call_openai(prompt, model='gpt-4o-mini'):
    if not OPENAI_API_KEY:
        raise RuntimeError('OPENAI_API_KEY not set')
    url = 'https://api.openai.com/v1/responses'
    headers = {'Authorization': f'Bearer {OPENAI_API_KEY}', 'Content-Type': 'application/json'}
    payload = {'model': model, 'input': prompt}
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        return r.json()
async def call_anthropic(prompt, model='claude-3.0'):
    if not ANTHROPIC_API_KEY:
        raise RuntimeError('ANTHROPIC_API_KEY not set')
    url = 'https://api.anthropic.com/v1/complete'
    headers = {'x-api-key': ANTHROPIC_API_KEY, 'Content-Type': 'application/json'}
    payload = {'model': model, 'prompt': prompt, 'max_tokens': 300}
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        return r.json()
@app.post('/v1/llm')
async def llm_predict(req: LLMReq):
    backend = MODEL_BACKENDS[0] if MODEL_BACKENDS else 'openai'
    try:
        if backend.startswith('openai'):
            resp = await call_openai(req.prompt, model=req.model_hint)
            return {'model_used':'openai','raw':resp}
        elif backend.startswith('anthropic') or backend.startswith('claude'):
            resp = await call_anthropic(req.prompt, model=req.model_hint)
            return {'model_used':'anthropic','raw':resp}
        else:
            return {'model_used':'stub','text': req.prompt[::-1]}
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
@app.get('/health')
def health():
    return {'status':'ok'}
