from fastapi import FastAPI
from pydantic import BaseModel
import hashlib, base64
app = FastAPI(title='Embedder Stub')
class Req(BaseModel):
    text: str
@app.post('/embed')
def embed(req: Req):
    h = hashlib.sha256(req.text.encode()).digest()[:32]
    return {'id': base64.b64encode(h).decode(), 'vector': list(h[:16])}
@app.get('/health')
def health():
    return {'status':'ok'}
