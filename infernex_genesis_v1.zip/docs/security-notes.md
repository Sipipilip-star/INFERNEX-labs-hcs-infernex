# Security Notes (summary)

- Use Vault + ExternalSecrets for all API keys
- HSM for signature keys and on-chain proofs
- OPA policies to block risky jobs touching treasury without multisig label
- Regular pentests and smart-contract audits
