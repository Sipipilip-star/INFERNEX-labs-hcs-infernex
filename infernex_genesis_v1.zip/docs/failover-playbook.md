# Failover Playbook (summary)

- MirrorMaker failover: switch DNS to backup cluster, reconfigure producers
- Vault failover: promote standby Vault, update ExternalSecrets
- Producer reconfiguration: restart producers with new bootstrapServers
- Post-mortem: capture Merkle snapshots and replay logs for audit
